# Collating Timed Image Analysis Data Files


detach(package:plyr)
library(dplyr)
library(SizeExtractR)
library(ggplot2)
library(lme4)
library(tidyr)

# Collating Data
# Note that the Directory Variables were as named as follows at the user input prompt
# Observer.ID, Method, and Method.First
# To run the script the user must input these variable names when prompted  (case sensitive)
mypath = "C:/Users/liaml/OneDrive - Newcastle University/Coral Assist PhD/ImageJ tool paper/Image Analyses"

DB = SizeExtractR::Full_SizeExtractR_Workflow(path = mypath,
                                              known.calibration.length = 10,
                                              include.calibrations = F)

colnames(DB)

DB.image = DB %>%
  group_by(Photo.Order, Observer.ID, Method, Photo.Rep, Photo.Name) %>%
  summarise(Number.Colonies = length(Area))

DB.image$name = substr(DB.image$Photo.Name, 6,8)

TM = read.csv(paste0(mypath,"/Methods Timings.csv"))
TM$name = as.character(TM$name)
colnames(TM)
colnames(DB.image)

TM = left_join(TM,DB.image, by = c("Observer.ID","name"))
TM$Method = paste(TM$Method,TM$Photo.Order,sep="_")

TM.g = gather(TM, "Analysis.Method", "Analysis.Time", c("Time.ser.dm", "Time.man.dm"))
TM.g$Analysis.Method = recode(TM.g$Analysis.Method,
                              Time.man.dm = "Manual",
                              Time.ser.dm = "SizeExtractR")
# Remove duplicate rows
TM.g = TM.g[which((TM.g$Method == paste(TM.g$Analysis.Method,TM$Photo.Order,sep="_")) == TRUE),]

# Backward selection start: ----------------------------------- -- 
# Full general linear model including observer ID and Method.First
Mod.int = lm(Analysis.Time ~ Number.Colonies * Analysis.Method + Observer.ID + Method.First, data = TM.g)
#Assumptions Check
plot(Mod.int)
# Results
summary(Mod.int)


# Backward selection round 1:
# Removal of Observer.ID as non-significant effect
Mod.int = lm(Analysis.Time ~ Number.Colonies * Analysis.Method + Method.First, data = TM.g)
#Assumptions Check
plot(Mod.int)
# Results
summary(Mod.int)

# Backward selection round 2:
# Removal of Method.First as non-significant effect
Mod.int = lm(Analysis.Time ~ Number.Colonies * Analysis.Method, data = TM.g)
#Assumptions Check
plot(Mod.int)
# Results
summary(Mod.int)


# Deriving sttistical results ----------------------------------- -- 
# For a given no. corals
N = c(1,10,40)
# what is the percentage reduction that SizeExtractR achieves
1 - (predict(Mod.int, newdata = data.frame(Number.Colonies = N, Analysis.Method = "SizeExtractR"))/ predict(Mod.int, newdata = data.frame(Number.Colonies = N, Analysis.Method = "Manual")))
# how much time does SizeExtractR save
predict(Mod.int, newdata = data.frame(Number.Colonies = N, Analysis.Method = "Manual")) - predict(Mod.int, newdata = data.frame(Number.Colonies = N, Analysis.Method = "SizeExtractR"))

# Computing 95% confidence intervals ----------------------------------- -- 
newdata = data.frame(Number.Colonies = rep(seq(min(TM.g$Number.Colonies),
                                               max(TM.g$Number.Colonies), length.out = 100),2),
                     Analysis.Method = c(rep(levels(as.factor(TM.g$Analysis.Method))[1],100),
                                         rep(levels(as.factor(TM.g$Analysis.Method))[2],100)))
pred = predict(Mod.int, newdata, se=T)
newdata = cbind(newdata,pred)
newdata$pred.95ci.up = newdata$fit + 1.96 *  newdata$se.fit
newdata$pred.95ci.lo = newdata$fit - 1.96 *  newdata$se.fit


# Plotting Data ----------------------------------- -- 

G=
ggplot() +
  geom_point(data = TM.g,
             aes(x = Number.Colonies,
                 y = Analysis.Time,
                 colour = Analysis.Method),
             alpha = 0.15, shape = 16, size = 3) +
  geom_ribbon(data = newdata,
              aes(x = Number.Colonies,
                  ymin = pred.95ci.lo,
                  ymax = pred.95ci.up,
                  group = Analysis.Method),
              alpha = 0.2, colour = NA, fill = "grey50") +
  geom_line(data = newdata,
            aes(x = Number.Colonies,
                y = fit,
                colour = Analysis.Method),
            size = 1) +
  scale_colour_manual(values = c("#F8766D","#00BFC4"),
                      guide = guide_legend(title="Analysis method")) +
  labs(y = "Time spent\n(minutes/image)",
       x = "Number of corals outlined\n(No./image)") +
  scale_x_continuous(limits = c(0,45), expand = c(0,0)) +
  scale_y_continuous(limits = c(0,14), expand = c(0,0), breaks = c(0,3,6,9,12)) +
  theme_bw() +
  theme(panel.grid = element_blank(),
        legend.position = c(0.25,0.8))


pdf("Time Comparison.pdf", height = 3.6, width = 4)
G
dev.off()
